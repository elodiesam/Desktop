package upo.cpo3;


/**
 * Un Etat final d'automate fini
*/

public class EtatFinal extends Etat {

	/**
	 * Constructeur d'�tat final
	 */
	public EtatFinal(String nom) {
		super(nom,true);
	}

}
