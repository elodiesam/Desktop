package upo.cpo4;

/**
 * Created by elodisam on 08/10/2015.
 */

enum Tarif{
    prixIllimite,
    prixIllimite5,
    prixReduit,
    prixReduit5;
}

