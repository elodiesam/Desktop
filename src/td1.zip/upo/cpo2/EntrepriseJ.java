package upo.cpo2;

import upo.cpo2.Employe;

/**
 * Created by elodisam on 01/10/2015.
 */
public class EntrepriseJ{

    public EntrepriseJ(){
    }

    public static void main (String[]args){
        Employe e = Employe.InstancierEmploye("Aymeric", 12, 80);
    }
}