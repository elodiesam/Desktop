package upo.cpo5bis;

/**
 * Created by elodisam on 22/10/2015.
 */
public abstract class CompteAvecLimite extends Compte{
   private double plafondDepot;

    public CompteAvecLimite(Utilisateur utilisateur, int numero, double montantInitial) {
        super(utilisateur, numero, montantInitial);
    }

    public double getPlafondDepot() {
        return plafondDepot;
    }
}
