package upo.cpo5bis;

/**
 * Created by elodisam on 22/10/2015.
 */
abstract public class Compte {
    private Utilisateur utilisateur;
    private int numero;
    private double montantInitial;

    public Compte(Utilisateur utilisateur, int numero, double montantInitial){
        this.utilisateur = utilisateur;
        this.numero = numero;
        this.montantInitial = montantInitial;
    }

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getMontantInitial() {
        return montantInitial;
    }

    public void setMontantInitial(double montantInitial) {
        this.montantInitial = montantInitial;
    }

}
