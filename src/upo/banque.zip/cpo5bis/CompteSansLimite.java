package upo.cpo5bis;

/**
 * Created by elodisam on 22/10/2015.
 */
abstract public class CompteSansLimite {
    private double plafondDepot;

    public CompteSansLimite(double plafondDepot){
        plafondDepot = this.plafondDepot;
    }

    public double getPlafondDepot() {
        return plafondDepot;
    }

    public void setPlafondDepot(double plafondDepot) {
        this.plafondDepot = plafondDepot;
    }
}
