package upo.cpo5bis;

import java.util.List;

/**
 * Created by elodisam on 22/10/2015.
 */
public class Utilisateur {
    private  String nom;
    private List<Compte> comptes;



}
