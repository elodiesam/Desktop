package upo.cpo5bis;

/**
 * Created by elodisam on 22/10/2015.
 */
public class CompteEpargne extends CompteAvecLimite {
    private double minimumOperationDeCredit;

    public CompteEpargne(Utilisateur utilisateur, int numero, double montantInitial) {
        super(utilisateur, numero, montantInitial);
    }
}
